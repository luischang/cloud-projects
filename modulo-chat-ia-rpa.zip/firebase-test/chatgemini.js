const dotenv = require("dotenv");
const { GoogleGenerativeAI } = require("@google/generative-ai");

dotenv.config();
//Acceder a variables de entorno
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

//Acceder a Gemini model Flash
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash"});

//const ClientText = "Hola. mi nombre es Alberto y mi codigo es 456, me gustaría conocer mi plan contratado.";
//const ClientContext = "{ name: 'Luis', lastname: 'Martinez', plan: 'basico' ,codigo:'123'}\n{ name: 'Alberto', lastname: 'Godoy', plan: 'Premium' ,codigo:'456'}"

//Configuración de generacion
const generationConfig = {
    temperature: 2,
    topP: 0.95,
    topK: 40,
    maxOutputTokens: 8192,
    responseMimeType: "text/plain",
  };



//gymiaChat(ClientText,ClientContext);

async function gymiaChat(ClientText, ClientContext){
    const chatSession = model.startChat({
        generationConfig,
        history: [
          {
            role: "user",
            parts: [
              {text: "Pretende ser la recepcionista del gimnacio H&F quién debe atender a los usuarios a través de un chat, le brindarás la información respecto a su plan contratado basada en esta entrada:"},
              {text: ClientContext},
              {text: "En caso el código no coincida con ninguno de los usuarios registrados, deberás responder:" + 
                "'Lo siento, no encontré información sobre el código proporcionado.' y debes asegurarte que el nombre " +
                "proporcionado coincida con el nombre registrado en la base de datos. Si el nombre no coincide, deberás responder:" +
                "'Lo siento, el nombre y código proporcionado no coincide con el nombre registrado en el sistema.'"},
              
            ],
          },
        ],
      });
    
      const result = await chatSession.sendMessage(ClientText);
      console.log(result.response.text());
}

async function gymCalendarIA(ClientText, EventsWeek){
  const chatSession = model.startChat({
      generationConfig,
      history: [
        {
          role: "user",
          parts: [
            {text: "Recuerda la lista de eventos de la semana, los cuales deberás ofrecerlos a los usuarios que soliciten información sobre los eventos o clases de la semana:"},
            {text: EventsWeek},
            {text: "Si dentro del mensaje enviado la clase deseada no se encuentra dentro de la lista, deberás contestar:" + 
              "'Lo siento, no encontré información sobre la clase solicitada, por favor elige una disponible' y ofrecerle los horarios disponibles de todas las clases " +
              ". Si el evento coincide con el seleccionado deberás enviarle la lista de horarios disponibles junto con el profesor, cuando eliga una de las clases le enviarás:" +
              "'La clase seleccionado es: ' + clase + ' el cual se llevará a cabo el día ' + dia + ' a las ' + hora + ' horas con la profesora ' + profesor"},
            
          ],
        },
      ],
    });
  
    const result = await chatSession.sendMessage(ClientText);
    console.log(result.response.text());
}


//Exportar funciones
module.exports = { gymiaChat };
module.exports = { gymCalendarIA };














/*
  //generateChat();
  //generateText();
async function generateText() {
    try {
        //const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const prompt = "Cuentame un chiste de NodeJS";

        const result = await model.generateContent(prompt);
        const response = await result.response;
        //const text = result.response.candidates[0].content.parts[0].text;
        const text = response.text();
        console.log("Texto generado:", text);

        
    } catch (error) {
        console.error("Error al generar el texto:", error);
    }
    }



async function generateChat(){
    try {

        //const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash"});

        const chat = model.startChat({
          history: [
            {
              role: "user",
              parts: [{ text: "Hola, tengo 2 perros en casa" }],
            },
            {
              role: "model",
              parts: [{ text: "Genial! que te gustaria saber?" }],
            },
          ],
          generationConfig: {
            maxOutputTokens: 100,
          },
        });
      
        const msg = "Cuantos patos tengo en casa?";
      
        const result = await chat.sendMessage(msg);
        const response = await result.response;
        const text = response.text();
        console.log(text);

    } catch (error) {
        console.error("Error al generar el chat:", error);   
    }
} */


