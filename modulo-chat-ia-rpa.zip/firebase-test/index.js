const { gymiaChat } = require('./chatgemini');
const { getDataColection } = require('./firebase');
const {getAPICalendar} = require('./calendario');
const { gymCalendarIA } = require('./chatgemini');

//const ClientText = "Hola. Mi codigo es 11223344, me gustaría conocer mi plan contratado.";
const ClientText = "Hola quisiera registrarme en una clase de Zumba";

async function main() {
    //const ClientContext = await getDataColection(); // Usa await para obtener los datos de la colección, obtiene informacion de los clientes
    //gymiaChat(ClientText, ClientContext);
    //console.log(ClientContext);

    const EventsWeek = await getAPICalendar(); // Usa await para obtener los eventos de la semana
    gymCalendarIA(ClientText, EventsWeek);
    
}

main();
